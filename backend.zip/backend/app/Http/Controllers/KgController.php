<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KgController extends Controller
{
    //
}
